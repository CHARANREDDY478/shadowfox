### Task 2: Boston House Price Prediction
### IDE: Visual Studio Code
### Key Skills: Python, Kaggle-dataset, Machine learning
