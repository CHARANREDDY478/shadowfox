# Machine Learning intern at SYNC Intern's

![Untitled](https://user-images.githubusercontent.com/90950477/217753709-e8d67710-fcba-46cc-97b9-90ec26139067.jpg)

### Task 1: Chatbot
### Task 2: Boston House Price Prediction


